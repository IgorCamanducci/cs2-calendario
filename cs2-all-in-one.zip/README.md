# CS2 — Calendário único (HLTV)
- `cs2.ics`: calendário único para Google Agenda (90 dias).
- `index.html`: lista os jogos lendo o `cs2.ics`.
- `times.json`: edite a lista de times.
- `generate_calendars.py`: busca no HLTV e escreve o ICS (root).
- `.github/workflows/update.yml`: roda a cada 30 min.

URLs (GitHub Pages):
- Página: https://SEU_USUARIO.github.io/cs2-calendario/
- ICS:    https://SEU_USUARIO.github.io/cs2-calendario/cs2.ics
